Thanks for downloading this theme!

Theme Name: Anyar
Theme URL: https://bootstrapmade.com/anyar-free-multipurpose-one-page-bootstrap-theme/
Author: BootstrapMade
Author URL: https://bootstrapmade.com